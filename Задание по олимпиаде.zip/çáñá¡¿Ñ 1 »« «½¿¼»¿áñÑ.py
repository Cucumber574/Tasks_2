'''Задание 1'''

input(first_number = 6 * 2)
input(second_number = 2 + 3 * 2)
if first_number = second_number:
    print('1')
else:
    print('2')
